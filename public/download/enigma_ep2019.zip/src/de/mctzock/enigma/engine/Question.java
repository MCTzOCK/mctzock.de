package de.mctzock.enigma.engine;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import de.mctzock.enigma.engine.compile.Compiler;
import de.mctzock.enigma.gui.AnimalChoose;
import de.mctzock.enigma.gui.Home;
import de.mctzock.enigma.gui.LogoAni;
import de.mctzock.enigma.gui.Text;

public class Question {
	
	static JFrame jf;
	public static void animal_yes_or_no(String animal, String hat, String shoe, String color) {
		jf = new JFrame("Enigma Version 7.0 | gemacht f�r " + Home.name);
		JPanel jp = new JPanel();
		JLabel jl = new JLabel("<html><body><h1>Du hast eine/n</h1><h1 style='color:red'>" + animal + "</h1> <h1>in</h1><h1 style='color:red'> " + color + "</h1><h1>mit einer/m <h1 style='color:red'>" + hat + "</h1><h1> und </h1><h1 style='color:red'>" + shoe  + "</h1><h1>Willst du das Tier Benutzen (als Compiling  Key) oder nicht?");
		JButton yes = new JButton("<html><body><h1 style='color:green'>Ja</body></h3></html>");
		JButton no = new JButton("<html><body><h1 style='color:red'>Nein</body></h3></html>");
		
		jp.add(jl);
		jp.add(yes);
		jp.add(no);
		
		jf.add(jp);
		jf.setResizable(false);
		jf.pack();
		jf.setLocationRelativeTo(null);
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jf.setVisible(true);
		
		yes.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				yes_clicked();
			}
		});
		no.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				int operation = JOptionPane.showConfirmDialog(null, "<html><body><h3>Bist du dir Sicher?(Wenn du Nein/Abbrechen dr�ckst</h3><p></p><h3>wird das Tier genommen!)</h3></body></html>");
				if(operation == 0)
				{
					jf.setVisible(false);
					AnimalChoose.choose_animal();
				}else {
					yes_clicked();
				}
			}
		});
	}
	public static void yes_clicked()
	{
		jf.setVisible(false);
		compile_or_decompile();
	}
	public static void compile_or_decompile() {
		jf = new JFrame("Enigma Version 7.0 | gemacht f�r " + Home.name);
		JPanel jp = new JPanel();
		JLabel info = new JLabel("<html><body><h2>Was willst du machen?</body></h2></html>");
		JButton code = new JButton("<html><body><h2>Verschl�sseln</body></h2></html>");
		JButton decode = new JButton("<html><body><h2>Entschl�sseln</body></h2></html>");
		
		jp.setLayout(new GridLayout(3, 1));
		jp.add(info);
		jp.add(code);
		jp.add(decode);
	
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jf.setResizable(false);
		jf.setLocationRelativeTo(null);
		jf.add(jp);
		jf.setSize(500, 500);
		jf.setVisible(true);
		
		String animal_ = AnimalChoose.animal + "." + AnimalChoose.hat + "." + AnimalChoose.shoe + "." + AnimalChoose.color;
		
		code.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				jf.setVisible(false);
				try {
					Compiler.compile(Text.text_public, animal_);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		
		decode.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				jf.setVisible(false);
				try {
					Compiler.decompile(Text.text_public, animal_);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});	
	}
}