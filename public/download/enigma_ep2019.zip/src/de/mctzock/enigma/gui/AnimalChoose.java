package de.mctzock.enigma.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import de.mctzock.enigma.engine.Question;

public class AnimalChoose {
	
	public static String animal = "";
	public static String hat = "";
	public static String shoe = "";
	public static String color = "";
	
	public static void choose_animal() 
	{
		
		JFrame jf = new JFrame("Enigma Version 7.0 | gemacht f�r " + Home.name);
		JPanel jp = new JPanel();
		JButton lion = new JButton("<html><body><h2 style='color:green'>L�we</h2></body></html>");
		JButton penguin = new JButton("<html><body><h2 style='color:blue'>Pinguin</h2></body></html>");
		JButton giraffe = new JButton("<html><body><h2 style='color:purple'>Giraffe</h2></body></html>");
		JButton rabbit = new JButton("<html><body><h2 style='color:orange'>Hase</h2></body></html>");
		JOptionPane.showMessageDialog(null, "<html><body><h3>Bitte gebe ein Tier, eine Kopfbedeckung,</h3><h3> ein paar Schuhe umd eine Farbe an.</h3><p></p><h3>Diese Kombination ist dein 'Compiling Key',</h3> <h3>zu Deutsch Verschl�sselungs Schl�ssel. </h3><p></p><h3>Merke dir deinen Schl�ssel, nur mit diesem Schl�ssel kannst du den text wieder entschl�sseln.</h3></body></html>");
		
		jp.add(lion);
		jp.add(penguin);
		jp.add(giraffe);
		jp.add(rabbit);
		jf.add(jp);
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jf.setResizable(true);
		jf.pack();
		jf.setLocationRelativeTo(null);
		jf.setVisible(true);
		
		lion.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				animal = "L�we";
				choose_hat();
				jf.setVisible(false);
			}
		});
		penguin.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				animal = "Pinguin";
				choose_hat();
				jf.setVisible(false);
			}
		});
		giraffe.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				animal = "Giraffe";
				choose_hat();
				jf.setVisible(false);
			}
		});
		rabbit.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				animal = "Hase";
				choose_hat();
				jf.setVisible(false);
			}
		});
		
	}
	public static void choose_hat() {
		JFrame jf = new JFrame("Enigma Version 7.0 | gemacht f�r " + Home.name);
		JButton cap = new JButton("<html><body><h2 style='color:green'>Kappe</h2></body></html>");
		JButton cylinder = new JButton("<html><body><h2 style='color:blue'>Zylinder</h2></body></html>");
		JPanel jp = new JPanel();
		jp.add(cap);
		jp.add(cylinder);
		jf.add(jp);
		jf.setSize(400, 100);
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jf.setResizable(false);
		jf.setLocationRelativeTo(null);
		jf.setVisible(true);
		
		cap.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				hat = "Kappe";
				choose_shoe();
				jf.setVisible(false);
			}
		});
		cylinder.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				hat = "Zylinder";
				choose_shoe();
				jf.setVisible(false);
			}
		});
	}
	public static void choose_shoe() 
	{
		JFrame jf = new JFrame("Enigma Version 7.0 | gemacht f�r " + Home.name);

		JPanel jp = new JPanel();
		JButton sneakers = new JButton("<html><body><h2 style='color:purple'>Turnschuhe</h2></body></html>");
		JButton sandals = new JButton("<html><body><h2 style='color:green'>Sandalen</h2></body></html>");
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jf.setResizable(false);
		jp.add(sneakers);
		jp.add(sandals);
		jf.add(jp);
		jf.setSize(400, 100);
		jf.setLocationRelativeTo(null);
		jf.setVisible(true);
		
		sneakers.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				shoe = "Turnschuhe";
				jf.setVisible(false);
				choose_color();
			}
		});
		sandals.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				shoe = "Sandalen";
				jf.setVisible(false);
				choose_color();
			}
		});
	}
	public static void choose_color() {
		JFrame jf = new JFrame("Enigma Version 7.0 | gemacht f�r " + Home.name);
		JPanel jp = new JPanel();
		JButton blue = new JButton("<html><body><h2 style='color:blue'>Blau");
		JButton black = new JButton("<html><body><h2 style='color:black'>Schwarz");
		JButton purple = new JButton("<html><body><h2 style='color:#8904B1'>Lila");
		JButton yellow = new JButton("<html><body><h2 style='color:yellow'>Gelb");
		jp.add(blue);
		jp.add(black);
		jp.add(yellow);
		jp.add(purple);
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jf.setResizable(false);
		jf.add(jp);
		jf.pack();
		jf.setLocationRelativeTo(null);
		jf.setVisible(true);
		
		blue.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				jf.setVisible(false);
				color = "Blau";
				try {
					Continue();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		black.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				jf.setVisible(false);
				color = "Schwarz";
				try {
					Continue();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		purple.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				jf.setVisible(false);
				color = "Lila";
				try {
					Continue();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		yellow.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				jf.setVisible(false);
				color = "Gelb";
				try {
					Continue();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
	}
	
	public static void Continue() throws IOException {
		String ac = animal + "." + hat + "." + shoe + "." + color;
		System.out.println(ac);
		Question.animal_yes_or_no(animal, hat, shoe, color);
	}
	public static void Continue_(String a) throws IOException {
		System.out.println(a);
	}
			
}