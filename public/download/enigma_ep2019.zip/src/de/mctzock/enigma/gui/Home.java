package de.mctzock.enigma.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class Home {
		
	public static String name = "";
	
	
	public static void getName()
	{
		name = JOptionPane.showInputDialog("<html><body><h3>Bitte gebe Deinen Namen ein!</body></h3></html>");
		launch();
	}
	public static void launch()
	{
		JFrame jf = new JFrame("Enigma Version 7.0 | gemacht für " + name);
		JPanel jp = new JPanel();
		JButton write_text = new JButton("<html><body><h2>Text zum Ver-/Entschlüsseln schreiben</h2></body></html>");
		JButton info = new JButton("<html><body><h2>Infos zum Projekt</h2></body></html>");
		JButton exit_0 = new JButton("<html><body><h2 style='color:red'>Enigma schließen</h2></body></html>");
		JButton feedback = new JButton("<html><body><h2 style='color:#01DF01'>Feedback senden</h2></body></html>");
		jp.add(write_text);
		jp.add(info);
		jp.add(exit_0);
		jp.add(feedback);
		jf.add(jp);
		jf.setResizable(false);
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jf.pack();
		jf.setLocationRelativeTo(null);
		jf.setVisible(true);
		//action
		
		write_text.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				jf.setVisible(false);
				Text.write();
				}
		});
		info.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					Process r = Runtime.getRuntime().exec("cmd.exe /c start iexplore.exe https://enigma.mctzock.de");
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		exit_0.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				int operation = JOptionPane.showConfirmDialog(null, "<html><body><h3>Möchtest du das Programm wirklich beenden?</h3></body></html>");
				if(operation == 0)
				{
					System.exit(0);
				}
			}
		});
		feedback.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				try
				{
					Process r = Runtime.getRuntime().exec("cmd.exe /c start iexplore.exe https://enigma.mctzock.de/feedback.html");
				}catch (Exception e2)
				{
					e2.printStackTrace();
				}
				
			}
		});
	}
}