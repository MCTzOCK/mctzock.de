package de.mctzock.enigma.gui;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class LogoAni {
	
	public static void startanimation() throws InterruptedException
	{
		JFrame jf = new JFrame();
		JPanel jp = new JPanel(); 
		JLabel picture = new JLabel();
		JLabel enigma_pic = new JLabel();
		JLabel ep = new JLabel();
		ep.setIcon(new ImageIcon("img/de/mctzock/assets/pictures/exciting_physics.png"));
		JLabel info = new JLabel("<html><body><h1>Herzlich Willkommen zu der Enigma von MCTzOCK (Ben Siebert)");
		JLabel cpr = new JLabel("<html><body><h3>Copyright � 2019 MCTzOCK.de. All rights reserved.</h3></body></html>");
		picture.setIcon(new ImageIcon("img/de/mctzock/assets/pictures/mctzock.png"));
		enigma_pic.setIcon(new ImageIcon("img/de/mctzock/assets/pictures/enigma.png"));

		info.setLocation(1000, 0);
		jf.setSize(800, 400);
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jf.setResizable(false);
		
		jp.add(ep);
		jp.add(picture);
		jp.add(enigma_pic);
		jp.add(info);
		jp.add(cpr);
		jf.add(jp);
		
		jf.setSize(800, 500);
		jf.setLocationRelativeTo(null);
		jf.setVisible(true);
		Thread.sleep(3250);
		jf.setVisible(false);
		Home.getName();
	}
}

