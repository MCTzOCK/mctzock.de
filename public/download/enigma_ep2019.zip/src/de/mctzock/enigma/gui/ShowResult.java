package de.mctzock.enigma.gui;

import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.Transferable;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.filechooser.FileNameExtensionFilter;

public class ShowResult {
	
	public static void load(String text) throws IOException 
	{
		JFrame jf = new JFrame("Enigma Version 7.0 | gemacht f�r " + Home.name); 
		JPanel jp = new JPanel();
		JButton save_to_file = new JButton("<html><body><h2 style='color:#0489B1'>Text in Datei speichern</h2></body></html>");
		JButton returne = new JButton("<html><body><h2 style='color:#3ADF00'>Nochmal?</h2></body></html>");
		JButton s2c = new JButton("<html><body><h2 style='color:blue'>Kopieren</h2></body></html>");
		JButton exit_0 = new JButton("<html><body><h2 style='color:red'>Enigma schlie�en</h2></body></html>");
		JLabel info = new JLabel("null");
		JFileChooser chooser = new JFileChooser();
		FileNameExtensionFilter filter = new FileNameExtensionFilter("Enigma Dateien [.enigma]", "enigma");
		
		chooser.setFileFilter(filter);
		
		jp.setLayout(new GridLayout(5, 1));
		info.setText("<html><body><h2>" + text + "</h2></body></html>");
		jp.add(info);
		jp.add(save_to_file);
		jp.add(s2c);
		jp.add(returne);
		jp.add(exit_0);
		jf.add(jp);
		jf.setSize(600, 400);
		
		jf.setLocationRelativeTo(null);
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jf.setVisible(true);
		
		save_to_file.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				chooser.showSaveDialog(chooser);
				try {
					
					File file = new File(chooser.getSelectedFile().toString());
					FileWriter writer = new FileWriter(file);
					writer.write(text);
					writer.close();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		
		returne.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				jf.setVisible(false);
				Home.launch();
			}
		});
		s2c.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				    Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
				    Transferable transferable = new StringSelection(text);
				    clipboard.setContents(transferable, null);
				    JOptionPane.showMessageDialog(null, "Der Text wurde erfolgreich in deine Zwischenablage kopiert!");
			}
		});
		exit_0.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				int operation = JOptionPane.showConfirmDialog(null, "<html><body><h3>M�chtest du das Programm wirklich beenden?</h3></body></html>");
				if(operation == 0)
				{
					System.exit(0);
				}
			}
		});
	}
}