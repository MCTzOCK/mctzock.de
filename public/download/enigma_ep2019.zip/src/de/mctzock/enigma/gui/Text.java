package de.mctzock.enigma.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class Text {
	
	public static String text_public =  "";
	
	public static void write() 
	{
		//creating comps
		
		JFrame jf = new JFrame("Enigma Version 7.0 | gemacht f�r " + Home.name);
		JEditorPane editor = new JEditorPane();
		JPanel jp = new JPanel();
		editor.setText("Hier muss dein Text stehen!");
		JMenuBar menubar = new JMenuBar();
		JMenu file = new JMenu("<html><body><h2 style='color:red'>Aktionen</h2></body></html>");
		JButton save = new JButton("<html><body><h2 style='color:orange'>Speichern</body></h2></html>");
		JButton delete = new JButton("<html><body><h2 style='color:blue'>Text l�schen</body></h2></html>");
		JButton back = new JButton("<html><body><h2 style='color:purple'>Zur�ck zum Hauptbildschirm</body></h2></html>");
		JButton Continue = new JButton("<html><body><h2 style='color:green'>N�chster Schritt</body></h2></html>");
		
		//adding comps 
		file.add(save);
		file.add(delete);
		file.add(back);
		file.add(Continue);
		menubar.add(file);
		jf.setJMenuBar(menubar);
		jf.add(editor);
		jf.setSize(750, 700);
		jf.setLocationRelativeTo(null);
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jf.setVisible(true);
		
		save.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				String name = JOptionPane.showInputDialog("<html><body><h3>Bitte gebe einen Namen f�r die Datei an!</body></h3></html>");
				String text = editor.getText().toString();
				try {
					Process r = Runtime.getRuntime().exec("cmd.exe /c copy null > %userprofile%\\Desktop\\"+ name + ".enigma");
					Process r1 = Runtime.getRuntime().exec("cmd.exe /c echo " + text + " > %userprofile%\\Desktop\\" + name + ".enigma");
					JOptionPane.showMessageDialog(null, "<html><body><h3>Die Datei wurde erfolgreich auf deinem</h3><h3 style='color:red'>Desktop</h3><h3>erzeugt!</body></h3></html>");
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		delete.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				int operation = JOptionPane.showConfirmDialog(null, "<html><body><h4>M�chtest du wirklich deinen <h3 style='color:red'>kompletten</h3> <h4>Text l�schen?</body></h4></html>");
				if(operation == 0)
				{
					editor.setText("");
				}
			}
		});
		back.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				int operation = JOptionPane.showConfirmDialog(null, "<html><body><h3>M�chtest du wirklich zur�ck?<h2 style='color:red'> (Dein Text wird unwiderruflich gel�scht!)</h2></body></h3></html>");
				if(operation == 0)
				{
					jf.setVisible(false);
					Home.launch();
				}
			}
		});
		Continue.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				jf.setVisible(false);
				text_public = editor.getText();
				System.out.println(text_public);
				AnimalChoose.choose_animal();
			}
		});
	}
}
