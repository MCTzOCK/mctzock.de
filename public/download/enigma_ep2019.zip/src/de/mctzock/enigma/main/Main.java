package de.mctzock.enigma.main;

import java.io.IOException;

import de.mctzock.enigma.gui.LogoAni;

public class Main {
	
	public static void main(String[] args) throws IOException, InterruptedException {
		System.out.println("[LOADER] Loading Enigma version 7.0 by MCTzOCK");
		System.out.println("Copyright � 2019 Ben Siebert");
		LogoAni.startanimation();
		//Home.getName();
		//ShowResult.load("test");
	}
}